#ifndef Secrets_com_rambo350z
#define Secrets_com_rambo350z

//Wi-Fi connection info
const char WIFI_SSID_HOUSE[] = "Rambos_Wireless";
const char WIFI_PASSWORD[]   = "2htiduj1chel";

//SmartThings location and Personel Authorization Token Ids
const char locId[] = "71868941-69a8-4675-8e95-3cd47e79aa6d";
const char stPAT[] = "553393bb-168b-40ea-be31-c6de1f5cc94f";

#endif
