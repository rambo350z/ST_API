
#ifndef ST_IDs_h_com_rambo350z
#define ST_IDs_h_com_rambo350z

//SmartThings API Server address
const char STServer[] = "api.smartthings.com";

//SmartThings Rule IDs
//const char Some_Rule_ID[] = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";

//SmartThings Scene IDs
//const char Some_Scene_ID[] = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";

//SmartThings Device IDs
const char temp_hum_sensor[] =    "ff93c3c2-6364-4cab-9197-64184eaa1634";

//SmartThings raw JSON commands
//use raw {R"(Paste JSON Here)"} strings to avoid escaping the JSON
//const char Some_JSON_Raw[] {R"({"commands": [{"component": "main","capability": "switch","command":"on"}]})"};

#endif
