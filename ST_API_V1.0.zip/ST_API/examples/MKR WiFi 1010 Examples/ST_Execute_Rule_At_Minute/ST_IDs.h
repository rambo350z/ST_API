
#ifndef ST_IDs_h_com_rambo350z
#define ST_IDs_h_com_rambo350z

//SmartThings API Server address
const char STServer[] = "api.smartthings.com";

//SmartThings Rule IDs
const char Some_Rule[] =       "0b18bbd0-d366-4f99-bc5c-9c81c7912eda";
const char Some_Other_Rule[] = "0b18bbd0-d366-4f99-bc5c-9c81c7912eda";

//SmartThings Scene IDs
//const char Some_Scene_Off[] =  "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";
//const char Some_Scene_On[] =   "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";


//SmartThings Device IDs
const char Some_Light[] = "1e23aac8-60f6-4e3d-b64c-cc27f25fefc4";

//SmartThings raw JSON commands
//use raw {R"(Paste JSON Here)"} strings to avoid escaping the JSON
//const char Some_JSON_Raw[] {R"({"commands": [{"component": "main","capability": "switch","command":"on"}]})"};

#endif
