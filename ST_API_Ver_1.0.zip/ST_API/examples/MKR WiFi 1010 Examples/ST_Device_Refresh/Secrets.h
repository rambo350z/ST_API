#ifndef Secrets_com_rambo350z
#define Secrets_com_rambo350z

//Wi-Fi connection info
const char WIFI_SSID_HOUSE[] = "Your_WiFI_SSID";
const char WIFI_PASSWORD[]   = "WiFi_Password";

//SmartThings location and Personel Authorization Token Ids
const char locId[] = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";
const char stPAT[] = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";

#endif
