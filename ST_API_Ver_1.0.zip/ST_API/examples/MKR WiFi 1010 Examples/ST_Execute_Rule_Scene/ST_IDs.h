
#ifndef ST_IDs_h_com_rambo350z
#define ST_IDs_h_com_rambo350z

//SmartThings API Server address
const char STServer[] = "api.smartthings.com";

//SmartThings Rule IDs
const char Some_Rule[] =      "0b18bbd0-d366-4f99-bc5c-9c81c7912eda";

//SmartThings Scene IDs
const char Some_Scene_Off[] =  "4e209031-ec1a-45de-b588-894f5f4c0228";
const char Some_Scene_On[] = "96a5f1d6-0537-4da2-92c7-891ab08d2a14";


//SmartThings Device IDs
//const char Some_Light[] = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";

//SmartThings raw JSON commands
//use raw {R"(Paste JSON Here)"} strings to avoid escaping the JSON
//const char Some_JSON_Raw[] {R"({"commands": [{"component": "main","capability": "switch","command":"on"}]})"};

#endif
