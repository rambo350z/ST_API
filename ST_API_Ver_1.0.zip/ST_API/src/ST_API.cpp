
#include "ST_API.h"

void STControl::STRule(const char* ruleID) {
  ST_Request(ruleID, RuleExecute);
  _responseCode = GetRequestResponse();
} //end of STRulePos

void STControl::STScene(const char* sceneID) {
  ST_Request(sceneID, SceneExecute);
  _responseCode = GetRequestResponse();
} //end of STScene

void STControl::STDeviceCmd(const char* deviceId, deviceCmdTypes deviceCmd, const char* cmdData, bool onlineChk) {
  //break deviceCmd apart if neccessary
  uint8_t bufSize {6};
  char cmdData1[bufSize] {'\0'};
  char cmdData2[bufSize] {'\0'};
  if (deviceCmd != DeviceJSON && (strchr(cmdData, ',') || strchr(cmdData, ':'))) {
    const char delim[] {",:"};
    char tempData[10] {'\0'};
    strncpy(tempData, cmdData, 10);
    strncpy(cmdData1, (strtok(tempData, delim)), bufSize);
    strncpy(cmdData2, (strtok(NULL, delim)), bufSize);
  }
  char outJSON[_outBufSize] = {'\0'};
  uint16_t JSONSize {0};
  char* error {nullptr};
  char adjHue[13] {'\0'};
  double scaledHue {0.0};
  switch (deviceCmd) {
    case DeviceState:
      JSONSize = snprintf(outJSON, _outBufSize, _deviceCntl, cmdData);
      break;
    case DeviceDim:
      JSONSize = snprintf(outJSON, _outBufSize, _deviceDim, cmdData);
      break;
    case DeviceStateDim:
      JSONSize = snprintf(outJSON, _outBufSize, _deviceCntlDim, cmdData1, cmdData2);
      break;
    case DeviceColorTemp:
      JSONSize = snprintf(outJSON, _outBufSize, _deviceColorTemp, cmdData);
      break;
    case DeviceSatHue:
      //scale hue from 0 - 360 to 0 - 100
      scaledHue = strtod(cmdData2, &error);
      snprintf(adjHue, 12, ".2%f", ((scaledHue / 360) * 100));
      JSONSize = snprintf(outJSON, _outBufSize, _deviceColorSatHue, cmdData1, adjHue);
      break;
    case DeviceJSON:
      strncpy(outJSON, cmdData, sizeof(outJSON)); //just copy input json to outJSON
      JSONSize = strlen(outJSON);
      break;
    default:
      Serial.print("Invalid Deice Command Type: "); Serial.println(deviceCmd);
  }
  if (_logLevel >= 1) STPrintJSON(JSONSize, outJSON);
  STDeviceJSONCmd(deviceId, outJSON, onlineChk);
} //end of STDeviceCmd

void STControl::STDeviceRefresh(const char* deviceId, bool onlineChk) {
  uint16_t JSONSize = strlen(_deviceRefresh);
  if (_logLevel >= 1) STPrintJSON(JSONSize, _deviceRefresh);
  STDeviceJSONCmd(deviceId, _deviceRefresh, onlineChk);
}

void STControl::STDeviceJSONCmd(const char* deviceId, const char* cmdBuf, bool onlineChk) {
  _responseCode = true;
  if (onlineChk) _responseCode = STDeviceState(deviceId);
  if (!_responseCode) return;
  ST_Request(deviceId, DeviceCntrl, strlen(cmdBuf));
  _SSLClient->println(cmdBuf);
  _SSLClient->println();
  if(*_cbPtr) (*_cbPtr)(); //reset wdt via callback
  _responseCode = GetRequestResponse();
  return;
}

void STControl::STDeviceStatus(const char* deviceId, bool onlineChk) {
  _responseCode = true;
  if (onlineChk) _responseCode = STDeviceState(deviceId);
  if (!_responseCode) return;
  ST_Request(deviceId, GetDeviceStatus, 0);
  _responseCode = GetRequestResponse();
  return;
} //end of STDeviceStatus

bool STControl::STDeviceState(const char* deviceId) {
  ST_Request(deviceId, DeviceOnOff);
  _responseCode = GetRequestResponse();
  if (strstr(_responseBuf, "OFFLINE") && _responseCode == 200) {
    _responseCode = 1;
    return false;
  }
  return true;
} //end of STDeviceState

// void STControl::STWeather() {
//   ST_Request(_locId, Weather);
//   return GetRequestResponse();
// }

int16_t STControl::ST_Request(const char* Id, STEvents reqType, uint16_t contentLength) {
  if (_SSLClient->connect(_STServer, _SSLPort)) {
    if (_logLevel >= 1) {
      Serial.print("ST Request Started - Type is: "); Serial.print(reqType);
    }
    switch (reqType) {
      case RuleExecute:
        _SSLClient->print("POST /v1/rules/execute/"); _SSLClient->print(Id);
        _SSLClient->print("?locationId="); _SSLClient->print(_locId); _SSLClient->println(" HTTP/1.1");
        break;
      case SceneExecute:
        _SSLClient->print("POST /v1/scenes/"); _SSLClient->print(Id); _SSLClient->print("/execute");
        _SSLClient->print("?locationId="); _SSLClient->print(_locId); _SSLClient->println(" HTTP/1.1");
        break;
      case DeviceOnOff: case GetDeviceStatus:
        _SSLClient->print("GET /v1/devices/"); _SSLClient->print(Id);
        reqType == DeviceOnOff ? _SSLClient->print("/health") : _SSLClient->print("/status");
        _SSLClient->print("?locationId="); _SSLClient->print(_locId); _SSLClient->println(" HTTP/1.1");
        break;
      case DeviceCntrl:
        _SSLClient->print("POST /v1/devices/"); _SSLClient->print(Id); _SSLClient->println("/commands HTTP/1.1");
        break;
      case DeviceRefresh:
        //{R"({"commands": [{"component": "main","capability": "refresh","command":"refresh"}]})"}
        break;
      case Weather:
        _SSLClient->print("GET /v1/services/coordinate/locations/"); _SSLClient->print(Id);
        _SSLClient->print("/capabilities?name=weather");
        break;
      default:
        Serial.println(" - Unknown request type");
    }
    _SSLClient->print("Accept: "); _SSLClient->println("application/json");
    _SSLClient->println("Content-Type: application/json");
    _SSLClient->print("Content-Length: "); _SSLClient->println(contentLength);
    _SSLClient->print("Host: "); _SSLClient->println(_STServer);
    _SSLClient->println("User-Agent: Arduino/1.0");
    _SSLClient->print("Authorization: Bearer "); _SSLClient->println(_PAT);
    _SSLClient->println("Connection: close");
    _SSLClient->println();
    if (_logLevel >= 1) Serial.println(" : Request Complete");
  }
  else {
    Serial.println("SmartThing Server Connection Request Failed");
    return -1;
  }
  return 1;
}

int16_t STControl::GetRequestResponse() {
  if(*_cbPtr) (*_cbPtr)(); //reset wdt via callback
  if(!_getResponse) {
    _SSLClient->stop();
    _SSLClient->flush();
    return -1;
  }
  _responseBuf[0] = 0; //zero out buffer
  uint16_t timeOut = 300; //30 second timeout, 300 * delay of 100ms
  while (!_SSLClient->available()) {
    delay(100);
    timeOut--;
    if(*_cbPtr) (*_cbPtr)(); //reset wdt via callback
    if (!timeOut) {
      Serial.println("no response from server");
      _SSLClient->stop();
      Serial.println("Disconnected from server");
      return -1;
    }
  }
  //flags to control what gets printed and collected
  bool printHeader = false; //set to true to print until 1st new line
  if (_logLevel >= 2) printHeader = true;
  bool JSONPresent = false; //don't collect response until the start of JSON
  uint16_t JSONLen = 0;
  char responseStatus[4] = {0};
  uint16_t chrCnt = 0;
  //Read available incoming bytes from the server and process
  while (_SSLClient->available()) {
    //collect request response code in char 9 - 11
    char c = _SSLClient->read();
    if (chrCnt >= 9 && chrCnt <= 11) {
      responseStatus[chrCnt - 9] = c;
    }
    chrCnt++;
    if (printHeader) Serial.write(c);
    //print out only first header line
    if (c == '\n' && printHeader && _logLevel <= 2) printHeader = false; //set to true to print all headers
    //check to make sure there is room in the buffer
    if (JSONLen == _capacity - 1) {
      Serial.write("\n");
      Serial.println("****** WARNING: JSON RESPONSE LARGER THAN JSON BUFFER CAPACITY ******");
      JSONPresent = false; //don't process JSON data
      break;
    }
    if (JSONPresent) _responseBuf[JSONLen++] = c;//collect JSON response
    if (_SSLClient->peek() == '{' && !JSONPresent) JSONPresent = true; //enable collection of JSON if present
  }
  _SSLClient->stop();
  _responseCode = atoi(responseStatus);
  if (!JSONPresent || (strlen(_responseBuf) == 0)) return _responseCode; //no JSON in response, return negative response code
  //fix last char, unknown why last char of response is 255.
  if (_responseBuf[JSONLen - 1] == 255) _responseBuf[JSONLen - 1] = '}';
  _responseBuf[JSONLen] = 0; //terminate char array
  if (_logLevel >= 1) {
    Serial.print("JSON: "); Serial.print(_responseBuf);
    Serial.print(" : JSON length: "); Serial.println(strlen(_responseBuf));
  }
  return _responseCode;
} //end of GetRequestResponse()

void STControl::STPrintResponse() {
  switch (_responseCode) {
    case 200:
      Serial.print("Request Successful - Response Code: ");
      break;
    case 400:
      Serial.print("Bad Request: Incorrect Device or Scene Id length - Response Code: ");
      break;
    case 403:
      Serial.print("Unauthorized: Invalid Device, Rule or Scene Id - Response Code: ");
      break;
    case 422:
      Serial.print("Unprocessable Entity: Malformed JSON or Incorrect Rule Id length - Response Code: ");
      break;
    case 500:
      Serial.print("Server Error: ST Unexpected Error - Response Code: ");
      break;
    case 501:
      Serial.print("Not Implemented: Requested Feature Not Implemented - Response Code: ");
      break;  
    case 0:
      Serial.print("Device is Offline, Command not Sent - Response Code: ");
      break;
    case 1:
      Serial.print("Device is Offline - Response Code: ");
      break;
    case -1:
      Serial.print("Response Processing Disabled - Response Code: ");
      break;
    default:
      Serial.print("Request Failed for Unknown Reason- Response Code: ");
  }
  Serial.println(_responseCode);
  //Serial.print(_responseCode); Serial.print(" ");
}

//library helper functions
void STPrintJSON(uint16_t JSONSize,  const char* outJSON) {
  Serial.print(JSONSize); Serial.println(" char written to JSON Command - "); Serial.println(outJSON);
  JSONSize ? JSONSize = JSONSize : JSONSize = 0; //suppresses compiler warning when Serial.print is commented out
}

bool STCapValue(const char* deviceStatus, const char* capToGet, char termChar, char* capValue) {
  char* foundPos = strstr(deviceStatus, capToGet);
  if (!foundPos) return false; //capacity not found
  foundPos += strlen(capToGet); //move ptr past found string
  uint16_t cnt {0};
  while (foundPos) {
    //check to see if term char or end of string was found
    if (foundPos[cnt] == termChar || *foundPos == '\0') break;
    capValue[cnt] = foundPos[cnt];
    cnt++;
  }
  capValue[cnt] = '\0';
  //false if ran off end of string
  if(*foundPos == '\0') return false;
  return true;
}

void RemoveQuotes(char *str) {
    int i, j;
    const char c = '"';
    int len = strlen(str);
    for (i = j = 0; i < len; i++) {
        if (str[i] != c) str[j++] = str[i];
    }
    str[j] = '\0';
}