
#ifndef ST_API_h_com_rambo350z
#define ST_API_h_com_rambo350z

//version 1.0 20230819 - initial release

#include <Arduino.h>
#include <Client.h>

typedef enum  {
  DeviceState,
  DeviceDim,
  DeviceStateDim,
  DeviceColorTemp,
  DeviceSatHue,
  DeviceJSON,
  DeviceRefresh
} deviceCmdTypes;

class STControl {
  public:
    //constructors
    STControl(Client* SSLClient, const char* STServer, const char* locId, const char* PAT, char* responseBuf, void (*cbPtr)() = NULL) :
      _SSLClient {SSLClient},
      _STServer{STServer},
      _locId{locId},
      _PAT{PAT},
      _responseBuf{responseBuf},
      _cbPtr{cbPtr} {};
    virtual ~STControl() = default; //destructor
    //api methods
    void STRule(const char* ruleID);
    void STScene(const char* sceneID);
    bool STDeviceState(const char* deviceId);
    void STDeviceCmd(const char* deviceId, deviceCmdTypes deviceCmd, const char* cmdData, bool onlineChk = false);
    void STDeviceJSONCmd(const char* deviceId, const char* cmdBuf, bool onlineChk = false);
    void STDeviceStatus(const char* deviceId, bool onlineChk = false);
    void STDeviceRefresh(const char* deviceId, bool onlineChk = false);
    //void STWeather();
    


    //setters - getters
    void setOnLineChk(bool onlineChk) {
      _onlineChk = onlineChk;
    }
    bool onlineChk() {
      return _onlineChk;
    }

    void setLocation(const char* locId) {
      _locId = locId;
    }
    const char* Location() {
      return _locId;
    }

    void setPAT(const char* PAT) {
      _PAT = PAT;
    }
    const char* PAT() {
      return _PAT;
    }

    void setOutBufSize(uint16_t outBufSize) {
      _outBufSize = outBufSize;
    }
    void setCapacity(uint16_t capacity) {
      _capacity = capacity;
    }

    void setLogLevel(uint16_t logLevel) {
      _logLevel = logLevel;
    }

    //helpers
    int16_t STResponseCode() {
      return _responseCode;
    }

    void STPrintResponse();

    void STGetResponse (bool getResponse) {
      _getResponse = getResponse;
    }

  protected:

  private:
    typedef enum  {
        RuleExecute, //0
        SceneExecute, //1
        DeviceOnOff, //2
        DeviceCntrl, //3
        GetDeviceStatus, //4
        GetDeviceCap, //5
        DeviceRefresh, //6
        Weather, //7
        Forecast //8
    } STEvents;

    Client* _SSLClient;
    const uint16_t _SSLPort {443};
    const char* _STServer;
    const char* _locId;
    const char* _PAT;
    char* _responseBuf;
    int16_t _responseCode {0};
    uint16_t _capacity {2048};
    uint16_t _outBufSize {512};
    bool _onlineChk {false};
    uint8_t _logLevel {0};
    bool _getResponse {true};
    void (*_cbPtr)() { //used for wdt call back
      nullptr
    };

    //SmartThings Specifc Commands
    const char* _deviceCntl {R"({"commands":[{"component":"main","capability":"switch","command":"%s"}]})"};
    const char* _deviceCntlDim {R"({"commands":[{"component":"main","capability":"switch","command":"%s"},{"component":"main","capability":"switchLevel","command":"setLevel","arguments":[%s]}]})"};
    const char* _deviceDim {R"({"commands":[{"component":"main","capability":"switchLevel","command":"setLevel","arguments":[%s]}]})"};
    const char* _deviceColorTemp {R"({"commands":[{"component":"main","capability":"colorTemperature","command":"setColorTemperature","arguments":[%s]}]})"};;
    const char* _deviceColorSatHue {R"({"commands":[{"component":"main","capability":"colorControl","command":"setColor","arguments":[{"saturation":%s,"hue":%s}]}]})"};
    const char* _deviceRefresh {R"({"commands":[{"component":"main","capability":"refresh","command":"refresh"}]})"};
    //https://api.smartthings.com/v1/services/coordinate/locations/%7BlocationId%7D/capabilities?name=weather
    //https://api.smartthings.com/v1/services/coordinate/locations/%7BlocationId%7D/capabilities?name=forecast

    //private methods
    int16_t ST_Request(const char* Id, STEvents reqType, uint16_t contentLength = 0);
    int16_t GetRequestResponse();

};

//library helper functions
void STPrintJSON(uint16_t JSONSize, const char* outJSON);
bool STCapValue(const char* deviceStatus, const char* capToGet, char termChar, char* capValue);
void RemoveQuotes(char *str);

#endif
